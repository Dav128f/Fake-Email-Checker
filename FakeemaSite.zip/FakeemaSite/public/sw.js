const CACHE_NAME = 'fakeemail-v1.0.0';
const STATIC_CACHE_NAME = 'fakeemail-static-v1.0.0';
const DYNAMIC_CACHE_NAME = 'fakeemail-dynamic-v1.0.0';

// Files to cache immediately (critical resources)
const STATIC_ASSETS = [
  '/',
  '/src/main.tsx',
  '/src/index.css',
  '/src/App.tsx',
  '/src/pages/home.tsx',
  '/src/components/navigation.tsx',
  '/src/components/email-checker.tsx',
  '/src/components/bulk-checker.tsx',
  '/src/components/recent-checks.tsx',
  '/src/lib/domains.js',
  '/src/lib/email-validator.ts',
  '/manifest.json',
  // External resources
  'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('[SW] Installing service worker...');
  
  event.waitUntil(
    caches.open(STATIC_CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Caching static assets');
        // Don't fail if some resources can't be cached
        return Promise.allSettled(
          STATIC_ASSETS.map(url => 
            cache.add(url).catch(err => {
              console.warn(`[SW] Failed to cache ${url}:`, err);
              return null;
            })
          )
        );
      })
      .then(() => {
        console.log('[SW] Static assets cached successfully');
        // Force activation
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('[SW] Error caching static assets:', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating service worker...');
  
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            // Delete old cache versions
            if (cacheName !== STATIC_CACHE_NAME && 
                cacheName !== DYNAMIC_CACHE_NAME && 
                cacheName !== CACHE_NAME) {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[SW] Service worker activated');
        // Take control of all pages immediately
        return self.clients.claim();
      })
  );
});

// Fetch event - serve from cache with network fallback
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Skip non-GET requests
  if (request.method !== 'GET') {
    return;
  }
  
  // Skip browser extension requests
  if (url.protocol === 'chrome-extension:' || url.protocol === 'moz-extension:') {
    return;
  }
  
  // Skip dev server requests in development
  if (url.hostname === 'localhost' && url.port === '3000') {
    return;
  }
  
  event.respondWith(
    caches.match(request)
      .then((cachedResponse) => {
        // Return cached version if available
        if (cachedResponse) {
          console.log('[SW] Serving from cache:', request.url);
          return cachedResponse;
        }
        
        // Network request with caching
        return fetch(request)
          .then((networkResponse) => {
            // Don't cache failed responses
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }
            
            // Clone response for caching
            const responseToCache = networkResponse.clone();
            
            // Determine which cache to use
            let cacheName = DYNAMIC_CACHE_NAME;
            if (STATIC_ASSETS.includes(request.url) || 
                request.url.includes('fonts.googleapis.com') ||
                request.url.includes('cdnjs.cloudflare.com')) {
              cacheName = STATIC_CACHE_NAME;
            }
            
            // Cache the response
            caches.open(cacheName)
              .then((cache) => {
                console.log('[SW] Caching new resource:', request.url);
                cache.put(request, responseToCache);
              })
              .catch((error) => {
                console.warn('[SW] Failed to cache resource:', request.url, error);
              });
            
            return networkResponse;
          })
          .catch((error) => {
            console.warn('[SW] Network request failed:', request.url, error);
            
            // For navigation requests, serve offline page
            if (request.destination === 'document') {
              return caches.match('/').then(response => {
                return response || new Response(
                  `<!DOCTYPE html>
                  <html>
                  <head>
                    <title>Fakeemail - Offline</title>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <style>
                      body { 
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        min-height: 100vh;
                        margin: 0;
                        background: #f8fafc;
                        color: #334155;
                        text-align: center;
                        padding: 2rem;
                      }
                      .icon { font-size: 4rem; margin-bottom: 1rem; color: #0ea5e9; }
                      h1 { margin: 0 0 1rem 0; color: #0f172a; }
                      p { margin: 0 0 2rem 0; opacity: 0.8; max-width: 400px; }
                      button {
                        background: #0ea5e9;
                        color: white;
                        border: none;
                        padding: 0.75rem 2rem;
                        border-radius: 0.5rem;
                        font-size: 1rem;
                        cursor: pointer;
                        transition: background 0.2s;
                      }
                      button:hover { background: #0284c7; }
                    </style>
                  </head>
                  <body>
                    <div class="icon">📧</div>
                    <h1>Fakeemail is Offline</h1>
                    <p>You're currently offline, but you can still use Fakeemail! The email checker works completely client-side.</p>
                    <button onclick="window.location.reload()">Try Again</button>
                  </body>
                  </html>`,
                  {
                    headers: { 'Content-Type': 'text/html' }
                  }
                );
              });
            }
            
            // For other requests, return a generic offline response
            return new Response('Offline', { 
              status: 408,
              statusText: 'Request Timeout'
            });
          });
      })
  );
});

// Background sync for future features
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync:', event.tag);
  
  if (event.tag === 'domain-list-update') {
    event.waitUntil(updateDomainList());
  }
});

// Push notifications (for future features)
self.addEventListener('push', (event) => {
  console.log('[SW] Push notification received');
  
  const options = {
    body: 'Domain list has been updated with new disposable email providers.',
    icon: '/icon-192.png',
    badge: '/icon-96.png',
    tag: 'domain-update',
    requireInteraction: false,
    actions: [
      {
        action: 'view',
        title: 'View Updates'
      },
      {
        action: 'dismiss',
        title: 'Dismiss'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('Fakeemail Updated', options)
  );
});

// Notification click handling
self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification clicked:', event.action);
  
  event.notification.close();
  
  if (event.action === 'view') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Message handling (for communication with main thread)
self.addEventListener('message', (event) => {
  console.log('[SW] Message received:', event.data);
  
  if (event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
  
  if (event.data.type === 'CACHE_URLS') {
    event.waitUntil(
      caches.open(DYNAMIC_CACHE_NAME)
        .then(cache => cache.addAll(event.data.urls))
        .then(() => event.ports[0].postMessage({ success: true }))
        .catch((error) => {
          console.error('[SW] Failed to cache URLs:', error);
          event.ports[0].postMessage({ success: false, error: error.message });
        })
    );
  }
});

// Helper function to update domain list (for future features)
async function updateDomainList() {
  try {
    console.log('[SW] Updating domain list...');
    
    // In the future, this could fetch an updated domain list from a CDN
    // For now, we'll just refresh the cache
    const cache = await caches.open(STATIC_CACHE_NAME);
    await cache.delete('/src/lib/domains.js');
    
    // Fetch fresh copy
    const response = await fetch('/src/lib/domains.js');
    if (response.ok) {
      await cache.put('/src/lib/domains.js', response);
      console.log('[SW] Domain list updated successfully');
    }
  } catch (error) {
    console.error('[SW] Failed to update domain list:', error);
  }
}

// Error handling
self.addEventListener('error', (event) => {
  console.error('[SW] Service worker error:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
  console.error('[SW] Unhandled promise rejection:', event.reason);
});

// Logging for debugging
console.log('[SW] Service worker loaded');
console.log('[SW] Cache names:', { STATIC_CACHE_NAME, DYNAMIC_CACHE_NAME, CACHE_NAME });
console.log('[SW] Static assets to cache:', STATIC_ASSETS.length);
