# Overview

Fakeemail is a client-side fake email detection tool that validates email addresses against a comprehensive database of disposable and temporary email domains. The application is built as a single-page React application with a focus on user experience, featuring a modern sky blue and white design theme with smooth animations and responsive layout. The tool provides instant email validation, bulk checking capabilities, and maintains a history of recent checks locally.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The application uses a modern React-based single-page architecture built with TypeScript and Vite for fast development and optimized builds. The frontend follows a component-based design pattern with:

- **React Router**: Uses Wouter for lightweight client-side routing
- **State Management**: Utilizes React Query (@tanstack/react-query) for server state management and local useState/useContext for component state
- **UI Framework**: Built with Radix UI primitives and shadcn/ui components for accessibility and consistent design
- **Styling**: Tailwind CSS with CSS custom properties for theming, supporting both light and dark modes
- **PWA Support**: Includes service worker for offline functionality and PWA manifest for mobile installation

## Component Structure
The application is organized into logical component layers:

- **Pages**: Single home page that contains all sections (home, about, how-to-use, privacy, terms, contact)
- **Core Components**: EmailChecker, BulkChecker, RecentChecks for main functionality
- **UI Components**: Reusable shadcn/ui components for consistent interface elements
- **Navigation**: Sticky navigation with smooth scrolling and section highlighting

## Email Validation Logic
The core validation system operates entirely client-side:

- **Domain List**: Comprehensive list of 2000+ disposable email domains stored in a local TypeScript file
- **Validation Engine**: Pure JavaScript functions for email format validation and domain checking
- **Edge Case Handling**: Supports plus-addressing, subdomain detection, case normalization, and whitespace trimming
- **Local Storage**: Recent checks are persisted using browser localStorage with automatic cleanup

## Backend Architecture
The server component uses Express.js with TypeScript and follows a modular structure:

- **Express Server**: Handles static file serving and API routing (currently minimal API surface)
- **Development Setup**: Vite integration for hot module replacement and development server
- **Storage Interface**: Abstract storage layer with in-memory implementation (ready for database integration)
- **Session Management**: Cookie-based sessions with PostgreSQL session store configuration

## Data Layer
The application uses Drizzle ORM for database operations:

- **Schema Definition**: User authentication schema defined in shared directory
- **Database Agnostic**: Configured for PostgreSQL but abstracted through Drizzle ORM
- **Migration Support**: Drizzle Kit for database schema migrations
- **Type Safety**: Full TypeScript integration with Zod validation schemas

# External Dependencies

## Core Framework Dependencies
- **React 18**: Modern React with hooks and concurrent features
- **Vite**: Fast build tool and development server with TypeScript support
- **Wouter**: Lightweight React router for client-side navigation
- **TypeScript**: Full type safety across the entire codebase

## UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Radix UI**: Unstyled, accessible UI primitives for complex components
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Google Fonts**: Inter font family for modern typography
- **Font Awesome**: Icon library for visual elements

## State Management and Data Fetching
- **TanStack React Query**: Powerful data synchronization and caching library
- **React Hook Form**: Performant forms with minimal re-renders
- **Zod**: Runtime type validation for form data and API responses

## Database and Backend
- **Express.js**: Node.js web application framework
- **Drizzle ORM**: Type-safe SQL ORM with PostgreSQL support
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## Development and Build Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer
- **Replit Integration**: Development environment integration and error handling

## PWA and Performance
- **Service Worker**: Custom implementation for offline functionality and caching
- **Web App Manifest**: PWA configuration for mobile app-like experience
- **Intersection Observer**: Efficient scroll-based animations and section detection

The architecture prioritizes client-side performance, type safety, and developer experience while maintaining the flexibility to scale backend functionality as needed. The disposable email detection runs entirely in the browser without external API dependencies, ensuring fast response times and user privacy.