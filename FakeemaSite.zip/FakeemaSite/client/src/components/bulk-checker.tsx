import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { validateEmail, extractDomain } from "@/lib/email-validator";

interface BulkResult {
  email: string;
  domain: string;
  status: 'safe' | 'disposable';
}

export default function BulkChecker() {
  const [bulkEmails, setBulkEmails] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<BulkResult[]>([]);

  const parseEmails = (text: string): string[] => {
    return text
      .split(/[,\n\r]+/)
      .map(email => email.trim())
      .filter(email => email.length > 0 && email.includes('@'))
      .slice(0, 200); // Limit to 200 emails
  };

  const handleBulkCheck = useCallback(async () => {
    if (!bulkEmails.trim()) return;

    setIsProcessing(true);
    const emails = parseEmails(bulkEmails);
    
    // Simulate processing with delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1000));

    const bulkResults: BulkResult[] = emails.map(email => {
      const domain = extractDomain(email);
      const isDisposable = validateEmail(email);
      
      return {
        email,
        domain,
        status: isDisposable ? 'disposable' : 'safe',
      };
    });

    setResults(bulkResults);
    setIsProcessing(false);
  }, [bulkEmails]);

  const downloadCSV = useCallback(() => {
    if (results.length === 0) return;

    const csvContent = [
      ['Email', 'Domain', 'Status'].join(','),
      ...results.map(result => [
        result.email,
        result.domain,
        result.status
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `fakeemail-bulk-results-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, [results]);

  const emailCount = parseEmails(bulkEmails).length;

  return (
    <div className="bg-card rounded-2xl shadow-lg border border-border p-8 hover-float">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <i className="fas fa-list text-primary text-2xl mr-3"></i>
          <h3 className="text-2xl font-semibold">Bulk Email Checker</h3>
        </div>
        <span className="bg-accent text-accent-foreground px-3 py-1 rounded-full text-sm font-medium">
          CSV EXPORT
        </span>
      </div>
      
      <div className="space-y-4">
        <div>
          <Label htmlFor="bulk-emails" className="text-sm font-medium text-foreground block mb-2">
            Paste Multiple Emails (up to 200)
          </Label>
          <Textarea 
            id="bulk-emails" 
            value={bulkEmails}
            onChange={(e) => setBulkEmails(e.target.value)}
            placeholder="email1@example.com&#10;email2@tempmail.org&#10;email3@domain.com"
            rows={6}
            className="w-full px-4 py-3 bg-input border border-border rounded-xl focus:outline-none focus-glow resize-none font-mono text-sm"
            data-testid="textarea-bulk-emails"
            disabled={isProcessing}
          />
          <p className="text-xs text-muted-foreground mt-1">
            Separate emails by line breaks or commas. {emailCount > 0 && `Found ${emailCount} valid emails.`}
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button 
            onClick={handleBulkCheck}
            className="flex-1 bg-secondary hover:bg-secondary/80 text-secondary-foreground py-3 px-6 rounded-xl font-medium transition-all duration-300"
            disabled={isProcessing || emailCount === 0}
            data-testid="button-bulk-check"
          >
            <i className="fas fa-check-double mr-2"></i>
            {isProcessing ? "Processing..." : "Check All"}
          </Button>
          <Button 
            onClick={downloadCSV}
            className="bg-primary hover:bg-primary/90 text-primary-foreground py-3 px-6 rounded-xl font-medium transition-all duration-300"
            disabled={results.length === 0}
            data-testid="button-download-csv"
          >
            <i className="fas fa-download mr-2"></i>
            Download CSV
          </Button>
        </div>
      </div>

      {/* Bulk Results Table */}
      {results.length > 0 && (
        <div className="mt-6 overflow-x-auto" data-testid="bulk-results-table">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-medium">Email</th>
                <th className="text-left py-3 px-4 font-medium">Domain</th>
                <th className="text-left py-3 px-4 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {results.map((result, index) => (
                <tr key={index}>
                  <td className="py-3 px-4 font-mono text-xs" data-testid={`result-email-${index}`}>
                    {result.email}
                  </td>
                  <td className="py-3 px-4" data-testid={`result-domain-${index}`}>
                    {result.domain}
                  </td>
                  <td className="py-3 px-4">
                    <span 
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        result.status === 'safe' 
                          ? 'bg-success text-success-foreground' 
                          : 'bg-destructive text-destructive-foreground'
                      }`}
                      data-testid={`result-status-${index}`}
                    >
                      {result.status === 'safe' ? 'Safe' : 'Disposable'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
