import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { validateEmail, extractDomain } from "@/lib/email-validator";
import { useLocalStorage } from "@/hooks/use-local-storage";

interface ValidationResult {
  email: string;
  domain: string;
  isDisposable: boolean;
  timestamp: string;
}

export default function EmailChecker() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ValidationResult | null>(null);
  const [recentChecks, setRecentChecks] = useLocalStorage<ValidationResult[]>("fakeemail-recent-checks", []);

  const handleEmailCheck = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) return;

    setIsLoading(true);
    setResult(null);

    // Simulate processing delay for better UX
    await new Promise(resolve => setTimeout(resolve, 800));

    const domain = extractDomain(email);
    const isDisposable = validateEmail(email);
    
    const validationResult: ValidationResult = {
      email: email.trim(),
      domain,
      isDisposable,
      timestamp: new Date().toISOString(),
    };

    setResult(validationResult);
    
    // Add to recent checks (keep last 5)
    const updatedChecks = [validationResult, ...recentChecks.slice(0, 4)];
    setRecentChecks(updatedChecks);
    
    setIsLoading(false);
  }, [email, recentChecks, setRecentChecks]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    if (result) setResult(null); // Clear previous result when typing
  }, [result]);

  return (
    <div className="bg-card rounded-2xl shadow-lg border border-border p-8 hover-float">
      <div className="flex items-center mb-6">
        <i className="fas fa-search text-primary text-2xl mr-3"></i>
        <h3 className="text-2xl font-semibold">Email Validator</h3>
      </div>
      
      <form onSubmit={handleEmailCheck} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="email-input" className="text-sm font-medium text-foreground">
            Enter Email Address
          </Label>
          <div className="relative">
            <Input 
              type="email" 
              id="email-input" 
              value={email}
              onChange={handleInputChange}
              placeholder="example@domain.com"
              className="w-full px-4 py-4 text-lg bg-input border border-border rounded-xl focus:outline-none focus-glow pr-12"
              aria-describedby="email-help"
              data-testid="input-email-checker"
              disabled={isLoading}
            />
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-muted-foreground">
              <i className="fas fa-envelope"></i>
            </div>
          </div>
          <p id="email-help" className="text-sm text-muted-foreground">
            We'll check if this email uses a disposable domain
          </p>
        </div>
        
        <Button 
          type="submit" 
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-4 px-8 rounded-xl font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
          disabled={isLoading || !email.trim()}
          data-testid="button-check-email"
        >
          <i className="fas fa-shield-alt mr-2"></i>
          {isLoading ? "Checking..." : "Check Email"}
        </Button>
      </form>
      
      {/* Loading Skeleton */}
      {isLoading && (
        <div className="mt-8 animate-pulse" data-testid="loading-skeleton">
          <div className="h-4 bg-muted rounded w-1/4 mb-2"></div>
          <div className="h-16 bg-muted rounded-xl relative overflow-hidden">
            <div className="absolute inset-0 shimmer-bg animate-shimmer"></div>
          </div>
        </div>
      )}
      
      {/* Results Area */}
      {result && !isLoading && (
        <div className="mt-8 animate-fade-in" data-testid="result-area">
          <div className={`p-6 rounded-xl border-2 ${
            result.isDisposable 
              ? "border-destructive bg-destructive/10" 
              : "border-success bg-success/10"
          }`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className={`w-3 h-3 rounded-full mr-3 animate-pulse ${
                  result.isDisposable ? "bg-destructive" : "bg-success"
                }`}></div>
                <span className={`font-semibold ${
                  result.isDisposable ? "text-destructive" : "text-success"
                }`}>
                  {result.isDisposable ? "❌ Disposable Email" : "✅ Safe Email"}
                </span>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                result.isDisposable 
                  ? "bg-destructive text-destructive-foreground" 
                  : "bg-success text-success-foreground"
              }`}>
                {result.isDisposable ? "RISKY" : "VERIFIED"}
              </span>
            </div>
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Domain: <code className="bg-muted px-2 py-1 rounded font-mono text-xs">{result.domain}</code>
              </p>
              <p className={`text-sm ${
                result.isDisposable ? "text-destructive-foreground" : "text-success-foreground"
              }`}>
                {result.isDisposable 
                  ? "This email uses a disposable domain. Not recommended for registrations or important communications."
                  : "This email appears to use a legitimate domain. Safe to use for registrations and communications."
                }
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
