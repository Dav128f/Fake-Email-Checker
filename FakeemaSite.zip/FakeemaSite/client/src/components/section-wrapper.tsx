import { ReactNode } from "react";
import { useIntersectionObserver } from "@/hooks/use-intersection-observer";

interface SectionWrapperProps {
  id: string;
  className?: string;
  children: ReactNode;
}

export default function SectionWrapper({ id, className = "", children }: SectionWrapperProps) {
  const { elementRef, isVisible } = useIntersectionObserver({
    threshold: 0.1,
    rootMargin: '-100px 0px',
  });

  return (
    <section 
      id={id} 
      ref={elementRef}
      className={`section-reveal ${isVisible ? 'visible' : ''} ${className}`}
    >
      {children}
    </section>
  );
}
