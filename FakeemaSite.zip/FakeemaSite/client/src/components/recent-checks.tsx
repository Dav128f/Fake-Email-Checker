import { useLocalStorage } from "@/hooks/use-local-storage";

interface RecentCheck {
  email: string;
  domain: string;
  isDisposable: boolean;
  timestamp: string;
}

export default function RecentChecks() {
  const [recentChecks] = useLocalStorage<RecentCheck[]>("fakeemail-recent-checks", []);

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date().getTime();
    const checkTime = new Date(timestamp).getTime();
    const diffMinutes = Math.floor((now - checkTime) / (1000 * 60));
    
    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60) return `${diffMinutes} minute${diffMinutes !== 1 ? 's' : ''} ago`;
    
    const diffHours = Math.floor(diffMinutes / 60);
    if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
  };

  return (
    <div className="space-y-6">
      <div className="bg-card rounded-2xl shadow-lg border border-border p-6 hover-float">
        <div className="flex items-center mb-6">
          <i className="fas fa-history text-primary text-xl mr-3"></i>
          <h3 className="text-xl font-semibold">Recent Checks</h3>
        </div>
        
        <div className="space-y-3" data-testid="recent-checks-list">
          {recentChecks.length > 0 ? (
            recentChecks.map((check, index) => (
              <div 
                key={index} 
                className="flex items-center justify-between p-3 bg-muted/50 rounded-xl"
                data-testid={`recent-check-${index}`}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate" title={check.email}>
                    {check.email}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatTimeAgo(check.timestamp)}
                  </p>
                </div>
                <span 
                  className={`px-2 py-1 rounded-full text-xs font-medium ml-2 ${
                    check.isDisposable 
                      ? "bg-destructive text-destructive-foreground" 
                      : "bg-success text-success-foreground"
                  }`}
                >
                  {check.isDisposable ? "Risky" : "Safe"}
                </span>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground" data-testid="recent-checks-empty">
              <i className="fas fa-inbox text-4xl mb-3 opacity-50"></i>
              <p className="text-sm">No recent checks yet</p>
              <p className="text-xs mt-1">Your last 5 checks will appear here</p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="bg-card rounded-2xl shadow-lg border border-border p-6 hover-float">
        <h4 className="font-semibold mb-4 flex items-center">
          <i className="fas fa-chart-bar text-primary mr-2"></i>
          Quick Stats
        </h4>
        
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Domains Monitored</span>
            <span className="font-semibold text-foreground">2,000+</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Checks Today</span>
            <span className="font-semibold text-foreground">{recentChecks.length}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Success Rate</span>
            <span className="font-semibold text-success">99.9%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
