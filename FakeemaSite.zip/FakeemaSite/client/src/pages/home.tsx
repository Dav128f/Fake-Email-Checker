import { useEffect } from "react";
import SectionWrapper from "@/components/section-wrapper";
import EmailChecker from "@/components/email-checker";
import BulkChecker from "@/components/bulk-checker";
import RecentChecks from "@/components/recent-checks";

export default function Home() {
  useEffect(() => {
    // Register service worker for PWA functionality
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then((registration) => {
          console.log('SW registered: ', registration);
        })
        .catch((registrationError) => {
          console.log('SW registration failed: ', registrationError);
        });
    }
  }, []);

  return (
    <main>
      {/* Home Section */}
      <SectionWrapper id="home" className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
              Fake Email Checker
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Instantly detect disposable, temporary, and burner email addresses with our powerful client-side validation tool. 
              Protect your business from fake registrations and spam.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <EmailChecker />
              <BulkChecker />
            </div>
            <div className="lg:col-span-1">
              <RecentChecks />
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* About Section */}
      <SectionWrapper id="about" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">About Fakeemail</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Protecting businesses from fake registrations and maintaining email list quality since day one.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-2xl font-semibold">Why Fakeemail?</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Disposable email addresses pose a significant threat to businesses. They enable users to bypass verification processes, 
                  create multiple fake accounts, and avoid accountability. Our tool helps you maintain data quality and protect your platform.
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-card p-6 rounded-xl border border-border hover-float">
                  <div className="flex items-center mb-3">
                    <i className="fas fa-lightning-bolt text-primary text-xl mr-3"></i>
                    <h4 className="font-semibold">Instant Results</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">Get validation results in milliseconds with our optimized client-side processing.</p>
                </div>

                <div className="bg-card p-6 rounded-xl border border-border hover-float">
                  <div className="flex items-center mb-3">
                    <i className="fas fa-shield-alt text-primary text-xl mr-3"></i>
                    <h4 className="font-semibold">Privacy First</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">All processing happens locally. Your email data never leaves your browser.</p>
                </div>

                <div className="bg-card p-6 rounded-xl border border-border hover-float">
                  <div className="flex items-center mb-3">
                    <i className="fas fa-database text-primary text-xl mr-3"></i>
                    <h4 className="font-semibold">2000+ Domains</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">Comprehensive database of known disposable email providers, updated regularly.</p>
                </div>

                <div className="bg-card p-6 rounded-xl border border-border hover-float">
                  <div className="flex items-center mb-3">
                    <i className="fas fa-code text-primary text-xl mr-3"></i>
                    <h4 className="font-semibold">No API Keys</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">100% client-side operation means no signup, no limits, no API keys required.</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gradient-to-br from-primary/10 to-blue-600/10 rounded-2xl p-8 text-center">
                <i className="fas fa-envelope-open-text text-6xl text-primary mb-4 animate-bounce-light"></i>
                <h4 className="text-xl font-semibold mb-2">Trusted by Developers</h4>
                <p className="text-muted-foreground">Reliable email validation for modern web applications</p>
              </div>

              <div className="bg-card rounded-xl border border-border p-6">
                <h4 className="font-semibold mb-4">Common Disposable Email Patterns</h4>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <code className="bg-muted px-2 py-1 rounded text-xs font-mono">10minutemail.com</code>
                    <span className="text-destructive text-xs">Temporary</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <code className="bg-muted px-2 py-1 rounded text-xs font-mono">guerrillamail.com</code>
                    <span className="text-destructive text-xs">Disposable</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <code className="bg-muted px-2 py-1 rounded text-xs font-mono">mailinator.com</code>
                    <span className="text-destructive text-xs">Burner</span>
                  </div>
                  <div className="text-center pt-2 border-t border-border">
                    <span className="text-xs text-muted-foreground">...and 2000+ more domains</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* How to Use Section */}
      <SectionWrapper id="how-to-use" className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">How to Use Fakeemail</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Get started in seconds with our intuitive email validation process.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="text-center hover-float">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-primary">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Enter Email Address</h3>
              <p className="text-muted-foreground">Type or paste the email address you want to validate into the input field.</p>
            </div>

            <div className="text-center hover-float">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-primary">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Click Check Email</h3>
              <p className="text-muted-foreground">Our system instantly analyzes the domain against our comprehensive database.</p>
            </div>

            <div className="text-center hover-float">
              <div className="bg-primary/10 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <span className="text-2xl font-bold text-primary">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-4">Get Instant Results</h3>
              <p className="text-muted-foreground">Receive immediate feedback on whether the email uses a disposable domain.</p>
            </div>
          </div>

          <div className="bg-card rounded-2xl shadow-lg border border-border p-8">
            <h3 className="text-2xl font-semibold mb-6 flex items-center">
              <i className="fas fa-lightbulb text-primary mr-3"></i>
              Pro Tips
            </h3>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold text-success mb-2">✅ Best Practices</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <i className="fas fa-check text-success text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      Use bulk checking for processing multiple emails efficiently
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-success text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      Check your recent validation history in the sidebar
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-success text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      Export bulk results as CSV for record keeping
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-success text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      The tool works completely offline after first load
                    </li>
                  </ul>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold text-destructive mb-2">⚠️ What We Detect</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <i className="fas fa-times text-destructive text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      Temporary email services (10-minute mail, etc.)
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-times text-destructive text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      Disposable email providers
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-times text-destructive text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      Burner email domains
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-times text-destructive text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                      Common subdomain patterns used for spam
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="mt-8 p-4 bg-accent/50 rounded-xl">
              <div className="flex items-start space-x-3">
                <i className="fas fa-info-circle text-primary mt-1"></i>
                <div>
                  <h5 className="font-medium mb-1">Privacy Note</h5>
                  <p className="text-sm text-muted-foreground">
                    All email validation happens locally in your browser. We never send your emails to external servers 
                    or store them anywhere. Your privacy is completely protected.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* Privacy Policy Section */}
      <SectionWrapper id="privacy" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Privacy Policy</h2>
            <p className="text-xl text-muted-foreground">
              Your privacy is our priority. Learn how we protect your data.
            </p>
          </div>

          <div className="bg-card rounded-2xl shadow-lg border border-border p-8 space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Data Collection</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Fakeemail operates entirely within your browser. We do not collect, store, or transmit any personal information 
                or email addresses you enter into our tool. All validation processing happens locally on your device.
              </p>
              <div className="bg-success/10 border border-success/20 rounded-lg p-4">
                <div className="flex items-center">
                  <i className="fas fa-shield-alt text-success mr-2"></i>
                  <span className="text-sm font-medium text-success">100% Client-Side Processing</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Local Storage</h3>
              <p className="text-muted-foreground leading-relaxed">
                We use your browser's local storage to maintain your "Recent Checks" history for convenience. This data never 
                leaves your device and can be cleared at any time through your browser settings or by clearing our site data.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Analytics</h3>
              <p className="text-muted-foreground leading-relaxed">
                We do not use any third-party analytics services or tracking cookies. Your usage of Fakeemail is completely private and anonymous.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Third-Party Services</h3>
              <p className="text-muted-foreground leading-relaxed">
                Our tool uses CDN-hosted resources (fonts, icons, CSS frameworks) for optimal performance. These services may 
                log basic request information, but no personal data is transmitted.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Updates to Policy</h3>
              <p className="text-muted-foreground leading-relaxed">
                Any changes to this privacy policy will be clearly communicated. We are committed to maintaining the same 
                level of privacy protection that our tool was built upon.
              </p>
            </div>

            <div className="border-t border-border pt-6">
              <p className="text-sm text-muted-foreground text-center">
                Last updated: January 2024. Contact us at{" "}
                <a href="mailto:fakeeemail8989@gmail.com" className="text-primary hover:underline">fakeeemail8989@gmail.com</a>{" "}
                for any privacy-related questions.
              </p>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* Terms & Conditions Section */}
      <SectionWrapper id="terms" className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Terms & Conditions</h2>
            <p className="text-xl text-muted-foreground">
              Please read these terms carefully before using our service.
            </p>
          </div>

          <div className="bg-card rounded-2xl shadow-lg border border-border p-8 space-y-8">
            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Service Description</h3>
              <p className="text-muted-foreground leading-relaxed">
                Fakeemail provides a free email validation service to detect disposable, temporary, and burner email addresses. 
                The service is provided "as is" without warranties of any kind.
              </p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Acceptable Use</h3>
              <div className="space-y-3">
                <p className="text-muted-foreground leading-relaxed">You may use this service for:</p>
                <ul className="space-y-2 text-muted-foreground ml-6">
                  <li className="flex items-start">
                    <i className="fas fa-check text-success text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                    Validating email addresses for legitimate business purposes
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check text-success text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                    Improving data quality in your applications
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check text-success text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                    Preventing spam and fake registrations
                  </li>
                </ul>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-4 text-primary">Limitations</h3>
              <div className="space-y-3">
                <p className="text-muted-foreground leading-relaxed">Please note the following limitations:</p>
                <ul className="space-y-2 text-muted-foreground ml-6">
                  <li className="flex items-start">
                    <i className="fas fa-exclamation-triangle text-yellow-500 text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                    Results are based on our domain database and may not be 100% accurate
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-exclamation-triangle text-yellow-500 text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                    New disposable domains may not be immediately detected
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-exclamation-triangle text-yellow-500 text-xs mt-1.5 mr-2 flex-shrink-0"></i>
                    Some legitimate domains might be incorrectly flagged (false positives)
                  </li>
                </ul>
              </div>
            </div>

            <div className="border-t border-border pt-6">
              <p className="text-sm text-muted-foreground text-center">
                Last updated: January 2024. Questions about these terms? Contact us at{" "}
                <a href="mailto:fakeeemail8989@gmail.com" className="text-primary hover:underline">fakeeemail8989@gmail.com</a>
              </p>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* Contact Section */}
      <SectionWrapper id="contact" className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Get in Touch</h2>
            <p className="text-xl text-muted-foreground">
              Have questions, feedback, or suggestions? We'd love to hear from you.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-card rounded-2xl shadow-lg border border-border p-8 hover-float">
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <i className="fas fa-envelope text-primary mr-3"></i>
                Contact Form
              </h3>
              
              <form className="space-y-6" onSubmit={(e) => {
                e.preventDefault();
                const form = e.currentTarget;
                const formData = new FormData(form);
                const name = formData.get('name') as string;
                const email = formData.get('email') as string;
                const subject = formData.get('subject') as string;
                const message = formData.get('message') as string;
                
                const mailtoLink = `mailto:fakeeemail8989@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`)}`;
                window.location.href = mailtoLink;
              }}>
                <div className="space-y-2">
                  <label htmlFor="contact-name" className="text-sm font-medium text-foreground block">Your Name</label>
                  <input 
                    type="text" 
                    id="contact-name" 
                    name="name"
                    placeholder="John Doe"
                    className="w-full px-4 py-3 bg-input border border-border rounded-xl focus:outline-none focus-glow"
                    data-testid="input-contact-name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="contact-email" className="text-sm font-medium text-foreground block">Your Email</label>
                  <input 
                    type="email" 
                    id="contact-email" 
                    name="email"
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 bg-input border border-border rounded-xl focus:outline-none focus-glow"
                    data-testid="input-contact-email"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="contact-subject" className="text-sm font-medium text-foreground block">Subject</label>
                  <input 
                    type="text" 
                    id="contact-subject" 
                    name="subject"
                    placeholder="Feedback about Fakeemail"
                    className="w-full px-4 py-3 bg-input border border-border rounded-xl focus:outline-none focus-glow"
                    data-testid="input-contact-subject"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="contact-message" className="text-sm font-medium text-foreground block">Message</label>
                  <textarea 
                    id="contact-message" 
                    name="message"
                    rows={5}
                    placeholder="Your message here..."
                    className="w-full px-4 py-3 bg-input border border-border rounded-xl focus:outline-none focus-glow resize-none"
                    data-testid="textarea-contact-message"
                    required
                  />
                </div>
                
                <button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 px-8 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105"
                  data-testid="button-send-message"
                >
                  <i className="fas fa-paper-plane mr-2"></i>
                  Send Message
                </button>
              </form>
            </div>

            <div className="space-y-6">
              <div className="bg-card rounded-2xl shadow-lg border border-border p-8 hover-float">
                <h3 className="text-2xl font-semibold mb-6 flex items-center">
                  <i className="fas fa-info-circle text-primary mr-3"></i>
                  Contact Information
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <i className="fas fa-envelope text-primary"></i>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Email Address</p>
                      <a href="mailto:fakeeemail8989@gmail.com" className="text-primary hover:underline">
                        fakeeemail8989@gmail.com
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <i className="fas fa-clock text-primary"></i>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Response Time</p>
                      <p className="text-muted-foreground">Usually within 24-48 hours</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                      <i className="fas fa-globe text-primary"></i>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Service Area</p>
                      <p className="text-muted-foreground">Worldwide, 24/7 availability</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-primary/10 to-blue-600/10 rounded-2xl p-8 text-center">
                <i className="fas fa-heart text-4xl text-primary mb-4 animate-pulse"></i>
                <h4 className="text-xl font-semibold mb-2">We Value Your Feedback</h4>
                <p className="text-muted-foreground">
                  Your suggestions help us improve Fakeemail for everyone. Don't hesitate to reach out with ideas, 
                  bug reports, or feature requests.
                </p>
              </div>
            </div>
          </div>
        </div>
      </SectionWrapper>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <i className="fas fa-shield-alt text-primary text-2xl"></i>
                <h3 className="text-2xl font-bold logo-highlight">Fakeemail</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed mb-6">
                The most reliable fake email checker. Protect your business from disposable, temporary, 
                and burner email addresses with our comprehensive validation tool.
              </p>
              <div className="flex space-x-4">
                <a href="#home" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-github text-xl"></i>
                </a>
                <a href="#home" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-twitter text-xl"></i>
                </a>
                <a href="#home" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-linkedin text-xl"></i>
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#home" className="text-muted-foreground hover:text-primary transition-colors">Home</a></li>
                <li><a href="#about" className="text-muted-foreground hover:text-primary transition-colors">About</a></li>
                <li><a href="#how-to-use" className="text-muted-foreground hover:text-primary transition-colors">How to Use</a></li>
                <li><a href="#contact" className="text-muted-foreground hover:text-primary transition-colors">Contact</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2">
                <li><a href="#privacy" className="text-muted-foreground hover:text-primary transition-colors">Privacy Policy</a></li>
                <li><a href="#terms" className="text-muted-foreground hover:text-primary transition-colors">Terms of Service</a></li>
                <li><a href="mailto:fakeeemail8989@gmail.com" className="text-muted-foreground hover:text-primary transition-colors">Support</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border mt-8 pt-8 text-center">
            <p className="text-muted-foreground">
              Made with ❤️ by{" "}
              <a href="#contact" className="text-primary hover:underline font-medium">Syed Afnan — SYED AFNAN SAV</a>
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              © 2024 Fakeemail. All rights reserved. | Free fake email checker and validator.
            </p>
          </div>
        </div>
      </footer>
    </main>
  );
}
