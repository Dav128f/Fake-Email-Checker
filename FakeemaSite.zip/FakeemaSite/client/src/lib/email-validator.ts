import { isDomainDisposable } from './domains';

/**
 * Validates an email address and checks if it uses a disposable domain
 * @param email - The email address to validate
 * @returns true if the email uses a disposable domain, false if it's safe
 */
export function validateEmail(email: string): boolean {
  if (!email || typeof email !== 'string') {
    return false;
  }

  // Basic email format validation
  if (!isValidEmailFormat(email)) {
    return false;
  }

  // Extract domain and check against disposable list
  const domain = extractDomain(email);
  if (!domain) {
    return false;
  }

  return isDomainDisposable(domain);
}

/**
 * Extracts the domain from an email address
 * Handles edge cases like plus-addressing, multiple @ symbols, etc.
 * @param email - The email address
 * @returns The domain portion or empty string if invalid
 */
export function extractDomain(email: string): string {
  if (!email || typeof email !== 'string') {
    return '';
  }

  // Clean the email
  const cleanEmail = email.trim().toLowerCase();
  
  // Handle plus-addressing (everything before + is ignored)
  const emailWithoutPlus = cleanEmail.split('+')[0] + (cleanEmail.includes('@') ? '@' + cleanEmail.split('@')[1] : '');
  
  // Split by @ symbol
  const parts = emailWithoutPlus.split('@');
  
  if (parts.length !== 2) {
    return '';
  }

  const domain = parts[1];
  
  // Basic domain validation
  if (!isValidDomainFormat(domain)) {
    return '';
  }

  return domain;
}

/**
 * Validates email format using a comprehensive regex
 * @param email - The email address to validate
 * @returns true if format is valid, false otherwise
 */
export function isValidEmailFormat(email: string): boolean {
  if (!email || typeof email !== 'string') {
    return false;
  }

  // Remove leading/trailing whitespace
  email = email.trim();

  // Check basic constraints
  if (email.length > 320) { // RFC 5321 limit
    return false;
  }

  // Comprehensive email regex that handles most valid email formats
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(email)) {
    return false;
  }

  // Additional checks
  const [localPart, domain] = email.split('@');
  
  // Local part checks
  if (!localPart || localPart.length > 64) { // RFC 5321 local part limit
    return false;
  }

  // Domain checks
  if (!domain || domain.length > 255) { // RFC 1035 domain length limit
    return false;
  }

  // Check for consecutive dots
  if (email.includes('..')) {
    return false;
  }

  // Check for leading/trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  return true;
}

/**
 * Validates domain format
 * @param domain - The domain to validate
 * @returns true if format is valid, false otherwise
 */
export function isValidDomainFormat(domain: string): boolean {
  if (!domain || typeof domain !== 'string') {
    return false;
  }

  // Remove leading/trailing whitespace
  domain = domain.trim().toLowerCase();

  // Basic length check
  if (domain.length === 0 || domain.length > 255) {
    return false;
  }

  // Domain regex - allows for subdomains, international domains, etc.
  const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!domainRegex.test(domain)) {
    return false;
  }

  // Check that TLD exists and is valid
  const tldPart = domain.split('.').pop();
  if (!tldPart || tldPart.length < 2) {
    return false;
  }

  // Check for consecutive dots or hyphens
  if (domain.includes('..') || domain.includes('--')) {
    return false;
  }

  // Domain cannot start or end with hyphen
  if (domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }

  // Each label cannot start or end with hyphen
  const labels = domain.split('.');
  for (const label of labels) {
    if (label.startsWith('-') || label.endsWith('-') || label.length === 0) {
      return false;
    }
  }

  return true;
}

/**
 * Normalizes an email address for consistent processing
 * @param email - The email address to normalize
 * @returns The normalized email address
 */
export function normalizeEmail(email: string): string {
  if (!email || typeof email !== 'string') {
    return '';
  }

  let normalized = email.trim().toLowerCase();
  
  // Handle plus-addressing for Gmail and similar providers
  // Note: We're being conservative here and only normalizing for known providers
  if (normalized.includes('@gmail.com') || normalized.includes('@googlemail.com')) {
    const [local, domain] = normalized.split('@');
    const cleanLocal = local.split('+')[0].replace(/\./g, ''); // Remove dots and plus addressing
    normalized = `${cleanLocal}@${domain}`;
  }
  
  return normalized;
}

/**
 * Performs bulk email validation
 * @param emails - Array of email addresses to validate
 * @returns Array of validation results
 */
export function validateEmailsBulk(emails: string[]): Array<{
  email: string;
  domain: string;
  isValid: boolean;
  isDisposable: boolean;
  normalizedEmail: string;
}> {
  return emails.map(email => {
    const isValid = isValidEmailFormat(email);
    const domain = extractDomain(email);
    const isDisposable = isValid ? validateEmail(email) : false;
    const normalizedEmail = normalizeEmail(email);
    
    return {
      email: email.trim(),
      domain,
      isValid,
      isDisposable,
      normalizedEmail,
    };
  });
}

/**
 * Gets validation statistics
 * @param emails - Array of email addresses
 * @returns Statistics about the email validation results
 */
export function getValidationStats(emails: string[]) {
  const results = validateEmailsBulk(emails);
  
  const stats = {
    total: results.length,
    valid: 0,
    invalid: 0,
    disposable: 0,
    safe: 0,
    uniqueDomains: new Set<string>(),
    commonDomains: {} as Record<string, number>,
  };
  
  results.forEach(result => {
    if (result.isValid) {
      stats.valid++;
      
      if (result.isDisposable) {
        stats.disposable++;
      } else {
        stats.safe++;
      }
      
      if (result.domain) {
        stats.uniqueDomains.add(result.domain);
        stats.commonDomains[result.domain] = (stats.commonDomains[result.domain] || 0) + 1;
      }
    } else {
      stats.invalid++;
    }
  });
  
  return {
    ...stats,
    uniqueDomains: stats.uniqueDomains.size,
    topDomains: Object.entries(stats.commonDomains)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .map(([domain, count]) => ({ domain, count })),
  };
}

/**
 * Generates a detailed validation report for an email
 * @param email - The email address to analyze
 * @returns Detailed analysis of the email
 */
export function getEmailAnalysis(email: string) {
  const isValid = isValidEmailFormat(email);
  const domain = extractDomain(email);
  const isDisposable = isValid ? validateEmail(email) : false;
  const normalizedEmail = normalizeEmail(email);
  
  const analysis = {
    original: email.trim(),
    normalized: normalizedEmail,
    isValid,
    domain,
    isDisposable,
    risk: isDisposable ? 'high' : isValid ? 'low' : 'medium',
    issues: [] as string[],
    recommendations: [] as string[],
  };
  
  // Add specific issues and recommendations
  if (!isValid) {
    analysis.issues.push('Invalid email format');
    analysis.recommendations.push('Please enter a valid email address');
  }
  
  if (isDisposable) {
    analysis.issues.push('Uses disposable email domain');
    analysis.recommendations.push('Consider using a permanent email address');
  }
  
  if (email !== normalizedEmail) {
    analysis.recommendations.push('Email was normalized for consistency');
  }
  
  if (email.includes('+')) {
    analysis.recommendations.push('Plus-addressing detected - aliases may be used');
  }
  
  return analysis;
}
