import { useEffect, useRef, useState, RefObject } from 'react';

interface UseIntersectionObserverOptions extends IntersectionObserverInit {
  freezeOnceVisible?: boolean;
}

/**
 * Custom hook for using Intersection Observer API
 * @param options - IntersectionObserver options with optional freezeOnceVisible
 * @returns Object containing ref to attach to element and visibility state
 */
export function useIntersectionObserver({
  threshold = 0,
  root = null,
  rootMargin = '0%',
  freezeOnceVisible = false,
}: UseIntersectionObserverOptions = {}) {
  const [entry, setEntry] = useState<IntersectionObserverEntry>();
  const [isVisible, setIsVisible] = useState(false);
  const elementRef = useRef<HTMLElement>(null);

  const frozen = entry?.isIntersecting && freezeOnceVisible;

  const updateEntry = ([entry]: IntersectionObserverEntry[]): void => {
    setEntry(entry);
    setIsVisible(entry.isIntersecting);
  };

  useEffect(() => {
    const node = elementRef?.current; // DOM node
    const hasIOSupport = !!window.IntersectionObserver;

    if (!hasIOSupport || frozen || !node) return;

    const observerParams = { threshold, root, rootMargin };
    const observer = new IntersectionObserver(updateEntry, observerParams);

    observer.observe(node);

    return () => observer.disconnect();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [elementRef?.current, JSON.stringify(threshold), root, rootMargin, frozen]);

  return { 
    elementRef: elementRef as RefObject<HTMLElement>, 
    entry, 
    isVisible,
    isIntersecting: isVisible, // Alias for convenience
  };
}

/**
 * Hook for lazy loading content when element comes into view
 * @param options - IntersectionObserver options
 * @returns Object with ref, loading state, and visibility
 */
export function useLazyLoad(options: UseIntersectionObserverOptions = {}) {
  const { elementRef, isVisible } = useIntersectionObserver({
    ...options,
    freezeOnceVisible: true, // Once visible, keep it visible
  });
  
  const [hasLoaded, setHasLoaded] = useState(false);

  useEffect(() => {
    if (isVisible && !hasLoaded) {
      setHasLoaded(true);
    }
  }, [isVisible, hasLoaded]);

  return {
    elementRef,
    isVisible,
    hasLoaded,
    shouldLoad: isVisible || hasLoaded,
  };
}

/**
 * Hook for animating elements when they come into view
 * @param options - IntersectionObserver options
 * @returns Object with ref and animation state
 */
export function useRevealAnimation({
  threshold = 0.1,
  rootMargin = '-50px 0px',
  ...options
}: UseIntersectionObserverOptions = {}) {
  const { elementRef, isVisible } = useIntersectionObserver({
    threshold,
    rootMargin,
    freezeOnceVisible: true,
    ...options,
  });

  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    if (isVisible && !hasAnimated) {
      setHasAnimated(true);
    }
  }, [isVisible, hasAnimated]);

  return {
    elementRef,
    isVisible,
    hasAnimated,
    shouldAnimate: hasAnimated,
  };
}

/**
 * Hook for tracking scroll progress of an element
 * @param options - IntersectionObserver options
 * @returns Object with ref and scroll progress
 */
export function useScrollProgress(options: UseIntersectionObserverOptions = {}) {
  const [progress, setProgress] = useState(0);
  const elementRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

    const handleScroll = () => {
      const rect = element.getBoundingClientRect();
      const windowHeight = window.innerHeight;
      
      // Calculate progress based on element position
      let progress = 0;
      
      if (rect.top <= windowHeight && rect.bottom >= 0) {
        const visibleHeight = Math.min(rect.bottom, windowHeight) - Math.max(rect.top, 0);
        progress = visibleHeight / rect.height;
      }
      
      setProgress(Math.max(0, Math.min(1, progress)));
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll, { passive: true });
    
    // Initial calculation
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
    };
  }, []);

  return {
    elementRef,
    progress,
    isFullyVisible: progress === 1,
    isPartiallyVisible: progress > 0,
  };
}

/**
 * Hook for infinite scrolling functionality
 * @param callback - Function to call when loading more items
 * @param options - IntersectionObserver options
 * @returns Object with ref to attach to loading trigger element
 */
export function useInfiniteScroll(
  callback: () => void,
  options: UseIntersectionObserverOptions = {}
) {
  const { elementRef, isVisible } = useIntersectionObserver({
    threshold: 1.0,
    ...options,
  });

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isVisible && !isLoading) {
      setIsLoading(true);
      callback();
      // Reset loading state after a short delay
      setTimeout(() => setIsLoading(false), 100);
    }
  }, [isVisible, callback, isLoading]);

  return {
    elementRef,
    isLoading,
    isVisible,
  };
}

/**
 * Hook for tracking multiple elements intersection
 * @param options - IntersectionObserver options
 * @returns Functions to manage multiple observed elements
 */
export function useMultipleIntersectionObserver(
  options: UseIntersectionObserverOptions = {}
) {
  const [entries, setEntries] = useState<Map<Element, IntersectionObserverEntry>>(new Map());
  const observer = useRef<IntersectionObserver>();

  useEffect(() => {
    const observerParams = {
      threshold: options.threshold || 0,
      root: options.root || null,
      rootMargin: options.rootMargin || '0%',
    };

    observer.current = new IntersectionObserver((entries) => {
      setEntries(current => {
        const newEntries = new Map(current);
        entries.forEach(entry => {
          newEntries.set(entry.target, entry);
        });
        return newEntries;
      });
    }, observerParams);

    return () => {
      observer.current?.disconnect();
    };
  }, [options.threshold, options.root, options.rootMargin]);

  const observe = (element: Element) => {
    observer.current?.observe(element);
  };

  const unobserve = (element: Element) => {
    observer.current?.unobserve(element);
    setEntries(current => {
      const newEntries = new Map(current);
      newEntries.delete(element);
      return newEntries;
    });
  };

  const getEntry = (element: Element) => {
    return entries.get(element);
  };

  const isVisible = (element: Element) => {
    return entries.get(element)?.isIntersecting || false;
  };

  return {
    observe,
    unobserve,
    getEntry,
    isVisible,
    entries: Array.from(entries.values()),
  };
}
