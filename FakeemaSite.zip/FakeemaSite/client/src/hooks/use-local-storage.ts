import { useState, useEffect, useCallback } from 'react';

/**
 * Custom hook for managing localStorage with React state synchronization
 * @param key - The localStorage key
 * @param initialValue - The initial value if no stored value exists
 * @returns [storedValue, setValue] tuple similar to useState
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  // Get value from localStorage or use initial value
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === "undefined") {
      return initialValue;
    }

    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  // Return a wrapped version of useState's setter function that persists the new value to localStorage
  const setValue = useCallback((value: T | ((val: T) => T)) => {
    try {
      // Allow value to be a function so we have the same API as useState
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Save state
      setStoredValue(valueToStore);
      
      // Save to localStorage
      if (typeof window !== "undefined") {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      console.warn(`Error setting localStorage key "${key}":`, error);
    }
  }, [key, storedValue]);

  // Listen for changes to this localStorage key from other tabs/windows
  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key && e.newValue !== null) {
        try {
          setStoredValue(JSON.parse(e.newValue));
        } catch (error) {
          console.warn(`Error parsing localStorage key "${key}" from storage event:`, error);
        }
      }
    };

    // Listen for storage events from other tabs
    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [key]);

  return [storedValue, setValue] as const;
}

/**
 * Hook for managing localStorage with additional utilities
 * @param key - The localStorage key
 * @param initialValue - The initial value if no stored value exists
 * @returns Object with value, setValue, removeValue, and clear functions
 */
export function useLocalStorageAdvanced<T>(key: string, initialValue: T) {
  const [value, setValue] = useLocalStorage(key, initialValue);

  // Remove the stored value and reset to initial value
  const removeValue = useCallback(() => {
    try {
      if (typeof window !== "undefined") {
        window.localStorage.removeItem(key);
      }
      setValue(initialValue);
    } catch (error) {
      console.warn(`Error removing localStorage key "${key}":`, error);
    }
  }, [key, initialValue, setValue]);

  // Clear all localStorage (use with caution)
  const clearAll = useCallback(() => {
    try {
      if (typeof window !== "undefined") {
        window.localStorage.clear();
      }
    } catch (error) {
      console.warn('Error clearing localStorage:', error);
    }
  }, []);

  // Check if the key exists in localStorage
  const hasValue = useCallback(() => {
    if (typeof window === "undefined") {
      return false;
    }
    
    try {
      return window.localStorage.getItem(key) !== null;
    } catch (error) {
      console.warn(`Error checking localStorage key "${key}":`, error);
      return false;
    }
  }, [key]);

  // Get the raw string value from localStorage
  const getRawValue = useCallback(() => {
    if (typeof window === "undefined") {
      return null;
    }

    try {
      return window.localStorage.getItem(key);
    } catch (error) {
      console.warn(`Error getting raw localStorage key "${key}":`, error);
      return null;
    }
  }, [key]);

  // Get storage usage information
  const getStorageInfo = useCallback(() => {
    if (typeof window === "undefined") {
      return { used: 0, available: 0, total: 0 };
    }

    try {
      let used = 0;
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        if (key) {
          const value = window.localStorage.getItem(key);
          used += key.length + (value?.length || 0);
        }
      }

      // Estimate total storage (usually 5-10MB, we'll use 5MB as conservative estimate)
      const total = 5 * 1024 * 1024; // 5MB in bytes
      const available = total - used;

      return { used, available, total };
    } catch (error) {
      console.warn('Error getting storage info:', error);
      return { used: 0, available: 0, total: 0 };
    }
  }, []);

  return {
    value,
    setValue,
    removeValue,
    clearAll,
    hasValue,
    getRawValue,
    getStorageInfo,
  };
}

/**
 * Hook for managing an array in localStorage with common array operations
 * @param key - The localStorage key
 * @param initialValue - The initial array value
 * @returns Object with array utilities
 */
export function useLocalStorageArray<T>(key: string, initialValue: T[] = []) {
  const [array, setArray] = useLocalStorage<T[]>(key, initialValue);

  const push = useCallback((item: T) => {
    setArray(current => [...current, item]);
  }, [setArray]);

  const unshift = useCallback((item: T) => {
    setArray(current => [item, ...current]);
  }, [setArray]);

  const pop = useCallback(() => {
    let poppedItem: T | undefined;
    setArray(current => {
      poppedItem = current[current.length - 1];
      return current.slice(0, -1);
    });
    return poppedItem;
  }, [setArray]);

  const shift = useCallback(() => {
    let shiftedItem: T | undefined;
    setArray(current => {
      shiftedItem = current[0];
      return current.slice(1);
    });
    return shiftedItem;
  }, [setArray]);

  const removeAt = useCallback((index: number) => {
    setArray(current => current.filter((_, i) => i !== index));
  }, [setArray]);

  const removeItem = useCallback((item: T) => {
    setArray(current => current.filter(i => i !== item));
  }, [setArray]);

  const updateAt = useCallback((index: number, newItem: T) => {
    setArray(current => current.map((item, i) => i === index ? newItem : item));
  }, [setArray]);

  const clear = useCallback(() => {
    setArray([]);
  }, [setArray]);

  const find = useCallback((predicate: (item: T) => boolean) => {
    return array.find(predicate);
  }, [array]);

  const filter = useCallback((predicate: (item: T) => boolean) => {
    return array.filter(predicate);
  }, [array]);

  const slice = useCallback((start?: number, end?: number) => {
    return array.slice(start, end);
  }, [array]);

  const limitLength = useCallback((maxLength: number) => {
    if (array.length > maxLength) {
      setArray(current => current.slice(0, maxLength));
    }
  }, [array.length, setArray]);

  return {
    array,
    setArray,
    push,
    unshift,
    pop,
    shift,
    removeAt,
    removeItem,
    updateAt,
    clear,
    find,
    filter,
    slice,
    limitLength,
    length: array.length,
    isEmpty: array.length === 0,
  };
}
